package com.example.chattingapp.services;

import com.example.chattingapp.domain.SenderReceiverRelationDTO;
import com.example.chattingapp.domain.inbound.SenderReceiverRelationDTOIn;

import java.util.List;

public interface ISenderReceiverRelation {
   public List<SenderReceiverRelationDTO> showAllMessages();


  public void sendMessage(SenderReceiverRelationDTOIn senderReceiverRelationDTOIn);
}
