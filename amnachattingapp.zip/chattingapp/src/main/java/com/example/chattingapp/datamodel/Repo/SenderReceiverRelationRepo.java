package com.example.chattingapp.datamodel.Repo;

import com.example.chattingapp.datamodel.SenderReceiverRelation;
import com.example.chattingapp.domain.SenderReceiverRelationDTO;
import com.example.chattingapp.domain.UserDTO;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.List;

public interface SenderReceiverRelationRepo extends PagingAndSortingRepository<SenderReceiverRelation,String> {
    @Query("select new com.example.chattingapp.domain.SenderReceiverRelationDTO(senderId, receiverId, message) from SenderReceiverRelation")
    List<SenderReceiverRelationDTO> findAllMessages();
}
