package com.example.chattingapp.controller;

import com.example.chattingapp.domain.SenderReceiverRelationDTO;
import com.example.chattingapp.domain.inbound.SenderReceiverRelationDTOIn;
import com.example.chattingapp.services.ISenderReceiverRelation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class SenderReceiverRelationController {
    @Autowired
    ISenderReceiverRelation senderReceiverRelation;
    @GetMapping("senderReceiver/allMessages")
    public List<SenderReceiverRelationDTO> showMessages(){
        return senderReceiverRelation.showAllMessages();

    }
    @ResponseStatus(HttpStatus.CREATED)
    @PostMapping("senderReceiver/sendMessages")
    public void sendMessages(@RequestBody SenderReceiverRelationDTOIn senderReceiverRelationDTOIn){
        senderReceiverRelation.sendMessage(senderReceiverRelationDTOIn);
    }

}
