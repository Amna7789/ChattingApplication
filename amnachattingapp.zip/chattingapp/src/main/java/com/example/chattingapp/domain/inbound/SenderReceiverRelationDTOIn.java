package com.example.chattingapp.domain.inbound;

import com.example.chattingapp.datamodel.SenderReceiverRelation;
import com.example.chattingapp.domain.SenderReceiverRelationDTO;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor


public class SenderReceiverRelationDTOIn extends SenderReceiverRelationDTO {
        String senderId;
        String receiverId;
        String message;
        public SenderReceiverRelationDTOIn(String senderId, String receiverId, String message) {
                super(senderId, receiverId, message);
        }
}

