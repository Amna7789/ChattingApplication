package com.example.chattingapp.services.impl;

import com.example.chattingapp.datamodel.Repo.SenderReceiverRelationRepo;
import com.example.chattingapp.datamodel.SenderReceiverRelation;
import com.example.chattingapp.datamodel.User;
import com.example.chattingapp.domain.SenderReceiverRelationDTO;
import com.example.chattingapp.domain.inbound.SenderReceiverRelationDTOIn;
import com.example.chattingapp.services.ISenderReceiverRelation;
import com.example.chattingapp.shared.GenericModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service

public class SenderReceiverRelationServiceImpl implements ISenderReceiverRelation {
    @Autowired
    SenderReceiverRelationRepo senderReceiverRelationRepo;

    @Override
    public List<SenderReceiverRelationDTO> showAllMessages() {
        return senderReceiverRelationRepo.findAllMessages();
    }

    @Override
    public void sendMessage(SenderReceiverRelationDTOIn senderReceiverRelationDTOIn) {
        User user = new User();
       /* ModelMapper modelMapper = new ModelMapper();
       *//* senderReceiverRelationDTOIn.setSenderId(user.getId());
        senderReceiverRelationDTOIn.setReceiverId(user.getId());*//*
        SenderReceiverRelation srv = modelMapper.map(senderReceiverRelationDTOIn, SenderReceiverRelation.class);
        srv.setSenderId(user.getId());
        srv.setReceiverId(user.getId());*/
        SenderReceiverRelation srr = GenericModelMapper.map(senderReceiverRelationDTOIn,SenderReceiverRelation.class);
        srr.setSenderId(user.getId());
        srr.setReceiverId(user.getId());
        senderReceiverRelationRepo.save(srr);

    }
}
